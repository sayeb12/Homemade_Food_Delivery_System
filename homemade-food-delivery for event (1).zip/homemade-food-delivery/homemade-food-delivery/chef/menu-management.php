<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Authentication check
if (!isLoggedIn() || !isUserType('chef')) {
    header('Location: login.php');
    exit;
}

// Get chef information
$chef_id = $_SESSION['user_id'];

// Create uploads directory if it doesn't exist
if (!file_exists($uploadDirs['dishes'])) {
    mkdir($uploadDirs['dishes'], 0755, true);
}

// Fetch chef profile picture (assuming it's stored in users table)
$chef_profile = $db->selectOne("SELECT profile_picture FROM users WHERE id = ?", [$chef_id]);
$profile_picture = $chef_profile && $chef_profile['profile_picture'] ? '../Uploads/profiles/' . $chef_profile['profile_picture'] : '../assets/images/default-profile.jpg';

// AJAX: fetch dishes
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'list') {
    $search = $_GET['search'] ?? '';
    $category = $_GET['category'] ?? '';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $itemsPerPage = 6;
    $offset = ($page - 1) * $itemsPerPage;

    $query = "SELECT * FROM food_items WHERE chef_id = ?";
    $params = [$chef_id];

    if ($search) {
        $query .= " AND name LIKE ?";
        $params[] = "%$search%";
    }
    if ($category) {
        $query .= " AND category = ?";
        $params[] = $category;
    }

    // Get total count for pagination
    $totalQuery = "SELECT COUNT(*) as total FROM food_items WHERE chef_id = ?";
    $totalParams = [$chef_id];
    if ($search) {
        $totalQuery .= " AND name LIKE ?";
        $totalParams[] = "%$search%";
    }
    if ($category) {
        $totalQuery .= " AND category = ?";
        $totalParams[] = $category;
    }
    try {
        $totalResult = $db->selectOne($totalQuery, $totalParams);
        $totalItems = $totalResult['total'];
        $totalPages = ceil($totalItems / $itemsPerPage);

        $query .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $params[] = $itemsPerPage;
        $params[] = $offset;

        $dishes = $db->select($query, $params);
        if ($dishes === false) {
            $dishes = [];
        }
        echo json_encode(['dishes' => $dishes, 'totalPages' => $totalPages, 'currentPage' => $page]);
    } catch (Exception $e) {
        error_log("Error fetching dishes: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Server error fetching dishes']);
    }
    exit;
}

// AJAX: fetch order history
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'order_history') {
    try {
        $query = "SELECT o.id, o.customer_id, o.total_amount, o.delivery_address, o.created_at, 
                         oi.food_item_id, oi.quantity, oi.price, 
                         f.name AS food_name, f.image AS food_image, 
                         COALESCE(u.name, 'Unknown Customer') AS customer_name, 
                         p.payment_method, p.transaction_id
                  FROM orders o
                  JOIN order_items oi ON o.id = oi.order_id
                  JOIN food_items f ON oi.food_item_id = f.id
                  LEFT JOIN users u ON o.customer_id = u.id
                  JOIN payments p ON o.id = p.order_id
                  WHERE f.chef_id = ? AND o.status = 'confirmed'
                  ORDER BY o.created_at DESC";
        $orders = $db->select($query, [$chef_id]);
        if ($orders === false) {
            $orders = [];
        }
        echo json_encode(['orders' => $orders]);
    } catch (Exception $e) {
        error_log("Error fetching order history: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Server error fetching order history']);
    }
    exit;
}

// AJAX: fetch feedback
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'fetch_feedback') {
    try {
        $feedback = $db->select(
            "SELECT f.id, f.order_id, f.rating, f.comment, f.created_at, 
                    COALESCE(u.name, 'Unknown Customer') AS customer_name, 
                    GROUP_CONCAT(COALESCE(fi.name, 'Unknown Item')) AS item_names
             FROM feedback f
             LEFT JOIN users u ON f.customer_id = u.id
             LEFT JOIN order_items oi ON f.order_id = oi.order_id
             LEFT JOIN food_items fi ON oi.food_item_id = fi.id
             WHERE f.chef_id = ?
             GROUP BY f.id
             ORDER BY f.created_at DESC",
            [$chef_id]
        );
        if ($feedback === false) {
            $feedback = [];
        }
        echo json_encode(['status' => 'success', 'feedback' => $feedback]);
    } catch (Exception $e) {
        error_log("Error fetching feedback: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Server error fetching feedback']);
    }
    exit;
}

// AJAX: fetch one dish for editing
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    try {
        $dish = $db->selectOne("SELECT * FROM food_items WHERE id = ? AND chef_id = ?", [$_GET['id'], $chef_id]);
        if ($dish) {
            echo json_encode($dish);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Dish not found']);
        }
    } catch (Exception $e) {
        error_log("Error fetching dish: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Server error fetching dish']);
    }
    exit;
}

// AJAX: add/edit/delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isLoggedIn()) {
        echo json_encode(['status' => 'error', 'message' => 'Session expired. Please log in again.']);
        exit;
    }

    if ($_POST['action'] === 'delete') {
        try {
            $dish = $db->selectOne("SELECT image FROM food_items WHERE id = ? AND chef_id = ?", [$_POST['id'], $chef_id]);
            if ($dish && $dish['image'] && file_exists($uploadDirs['dishes'] . $dish['image'])) {
                unlink($uploadDirs['dishes'] . $dish['image']);
            }

            $db->delete("DELETE FROM food_items WHERE id = ? AND chef_id = ?", [$_POST['id'], $chef_id]);
            echo json_encode(['status' => 'success', 'message' => 'Dish deleted successfully']);
        } catch (Exception $e) {
            error_log("Error deleting dish: " . $e->getMessage());
            echo json_encode(['status' => 'error', 'message' => 'Server error deleting dish']);
        }
        exit;
    }

    $id = $_POST['id'] ?? '';
    $name = sanitizeInput($_POST['name'] ?? '');
    $desc = sanitizeInput($_POST['description'] ?? '');
    $peptime = (int)($_POST['preparation_time'] ?? 0);
    $price = (float)($_POST['price'] ?? 0);
    $qty = (int)($_POST['quantity'] ?? 0);
    $cat = sanitizeInput($_POST['category'] ?? '');
    $available = (int)($_POST['is_available'] ?? 0);
    $imageName = null;

    // Validate inputs
    if ($name === '') {
        echo json_encode(['status' => 'error', 'message' => 'Dish name is required']);
        exit;
    }
    if ($price <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Price must be greater than 0']);
        exit;
    }
    if ($qty < 0) {
        echo json_encode(['status' => 'error', 'message' => 'Quantity cannot be negative']);
        exit;
    }
    if ($peptime <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Preparation time must be greater than 0']);
        exit;
    }
    if (!in_array($cat, array_keys(getCategories()))) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid category']);
        exit;
    }

    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $uploadResult = uploadImage($_FILES['image'], $uploadDirs['dishes']);
        if ($uploadResult['success']) {
            $imageName = $uploadResult['fileName'];
        } else {
            echo json_encode(['status' => 'error', 'message' => $uploadResult['message']]);
            exit;
        }
    }

    try {
        if ($id) {
            // Update existing dish
            $dish = $db->selectOne("SELECT id, image FROM food_items WHERE id = ? AND chef_id = ?", [$id, $chef_id]);
            if (!$dish) {
                echo json_encode(['status' => 'error', 'message' => 'Unauthorized action']);
                exit;
            }

            $query = "UPDATE food_items SET name=?, description=?, price=?, quantity=?, category=?, is_available=?, preparation_time=?";
            $params = [$name, $desc, $price, $qty, $cat, $available, $peptime];

            if ($imageName) {
                if ($dish['image'] && file_exists($uploadDirs['dishes'] . $dish['image'])) {
                    unlink($uploadDirs['dishes'] . $dish['image']);
                }
                $query .= ", image=?";
                $params[] = $imageName;
            }

            $query .= " WHERE id=? AND chef_id=?";
            $params[] = $id;
            $params[] = $chef_id;

            $db->update($query, $params);
            echo json_encode(['status' => 'success', 'message' => 'Dish updated successfully']);
        } else {
            // Add new dish
            $query = "INSERT INTO food_items (chef_id, name, description, price, quantity, category, is_available, preparation_time, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $params = [$chef_id, $name, $desc, $price, $qty, $cat, $available, $peptime, $imageName];

            $db->insert($query, $params);
            echo json_encode(['status' => 'success', 'message' => 'Dish added successfully']);
        }
    } catch (Exception $e) {
        error_log("Error saving dish: " . $e->getMessage());
        echo json_encode(['status' => 'error', 'message' => 'Server error saving dish']);
    }
    exit;
}

// Fetch categories for form
$categories = getCategories();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Management - Homemade Food Delivery</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0.5)), 
                        url('https://images.unsplash.com/photo-1504674900247-087ca5f5c2f0') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            line-height: 1.6;
            overflow-x: hidden;
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes scaleIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        header {
            background: linear-gradient(90deg, #2e7d32, #66bb6a);
            padding: 15px 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            animation: fadeIn 0.8s ease-in-out;
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1300px;
            margin: 0 auto;
        }

        .logo img {
            height: 50px;
            filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
        }

        .user {
            display: flex;
            align-items: center;
            gap: 15px;
            background: rgba(255, 255, 255, 0.2);
            padding: 8px 15px;
            border-radius: 30px;
            transition: all 0.3s ease;
        }

        .user:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .user img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #fff;
        }

        .user div {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }

        .user div strong {
            font-size: 1.1em;
            color: #fff;
            font-weight: 500;
        }

        .user div span {
            font-size: 0.9em;
            color: #f5f5f5;
        }

        .btn {
            padding: 10px 20px;
            background: linear-gradient(45deg, #2e7d32, #66bb6a);
            color: #fff;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 0.95em;
            font-weight: 500;
            transition: all 0.3s ease;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
        }

        .btn:hover {
            background: linear-gradient(45deg, #66bb6a, #2e7d32);
            transform: translateY(-2px);
            box-shadow: 0 5px 12px rgba(0, 0, 0, 0.2);
            animation: pulse 0.5s infinite;
        }

        .btn-dark {
            background: linear-gradient(45deg, #dc3545, #e74c3c);
        }

        .btn-dark:hover {
            background: linear-gradient(45deg, #e74c3c, #dc3545);
        }

        .main-container {
            max-width: 1300px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .tab-button {
            padding: 10px 20px;
            background: #e0e0e0;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .tab-button.active {
            background: #2e7d32;
            color: #fff;
        }

        .tab-content {
            display: none;
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            border: 1px solid #a5d6a7;
            animation: slideUp 0.5s ease-in-out;
        }

        .tab-content.active {
            display: block;
        }

        .section-title {
            text-align: center;
            margin-bottom: 30px;
        }

        .section-title h2 {
            font-size: 2.5em;
            color: #2e7d32;
            font-weight: 700;
            position: relative;
        }

        .section-title h2::after {
            content: '';
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, #2e7d32, #66bb6a);
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
        }

        .filter-container {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filter-container input, .filter-container select {
            padding: 10px;
            border: 1px solid #a5d6a7;
            border-radius: 8px;
            font-size: 0.95em;
            background: #f1f8e9;
            flex: 1;
            min-width: 150px;
        }

        .filter-container select {
            background: #f1f8e9 url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12"><path d="M6 9l-4-4h8z" fill="%232e7d32"/></svg>') no-repeat right 10px center;
            appearance: none;
        }

        .filter-container input:focus, .filter-container select:focus {
            border-color: #388e3c;
            box-shadow: 0 0 8px rgba(56, 142, 60, 0.3);
            background: #fff;
        }

        .dish-grid, .order-grid, .feedback-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        .dish-card, .order-card, .feedback-card {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            border: 1px solid #a5d6a7;
            transition: all 0.3s ease;
        }

        .dish-card:hover, .order-card:hover, .feedback-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }

        .dish-image, .order-image {
            height: 200px;
            overflow: hidden;
        }

        .dish-image img, .order-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .dish-card:hover .dish-image img, .order-card:hover .order-image img {
            transform: scale(1.1);
        }

        .dish-content, .order-content, .feedback-content {
            padding: 15px;
        }

        .dish-content h3, .order-content h3, .feedback-content h3 {
            font-size: 1.5em;
            color: #2d3436;
            margin-bottom: 10px;
        }

        .dish-content p, .order-content p, .feedback-content p {
            color: #636e72;
            margin-bottom: 8px;
        }

        .dish-actions, .order-actions {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal.show {
            display: flex;
        }

        .modal-content {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            width: 90%;
            max-width: 500px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            animation: scaleIn 0.3s ease-in-out;
            border: 1px solid #66bb6a;
        }

        .modal-content h3 {
            color: #2e7d32;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            color: #2e7d32;
            font-weight: 500;
            margin-bottom: 5px;
        }

        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #a5d6a7;
            border-radius: 8px;
            font-size: 0.95em;
            background: #f1f8e9;
            box-sizing: border-box;
        }

        .form-group select {
            background: #f1f8e9 url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12"><path d="M6 9l-4-4h8z" fill="%232e7d32"/></svg>') no-repeat right 10px center;
            appearance: none;
        }

        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            border-color: #388e3c;
            box-shadow: 0 0 8px rgba(56, 142, 60, 0.3);
            background: #fff;
        }

        .form-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #a5d6a7;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }

        .pagination button {
            padding: 8px 16px;
            border: 1px solid #a5d6a7;
            border-radius: 8px;
            background: #f1f8e9;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .pagination button:hover {
            background: #a5d6a7;
            color: #fff;
        }

        .pagination button:disabled {
            background: #e0e0e0;
            cursor: not-allowed;
        }

        footer {
            background: linear-gradient(90deg, #2e7d32, #66bb6a);
            color: #fff;
            padding: 20px;
            text-align: center;
            margin-top: 40px;
        }

        @media (max-width: 768px) {
            .filter-container {
                flex-direction: column;
            }

            .dish-grid, .order-grid, .feedback-grid {
                grid-template-columns: 1fr;
            }

            .modal-content {
                width: 95%;
                padding: 15px;
            }

            .tabs {
                flex-direction: column;
            }

            .tab-button {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <a href="../index.php"><img src="../assets/images/logo.png" alt="Homemade Food Delivery"></a>
            </div>
            <div class="user">
                <img src="<?php echo htmlspecialchars($profile_picture); ?>" alt="Profile Picture" onerror="this.src='../assets/images/default-profile.jpg';">
                <div>
                    <strong><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Chef'); ?></strong>
                    <span><?php echo htmlspecialchars($_SESSION['user_location'] ?? ''); ?></span>
                </div>
                <a href="../logout.php" class="btn btn-dark">Log Out</a>
            </div>
        </div>
    </header>

    <div class="main-container">
        <div class="section-title">
            <h2>Menu Management</h2>
        </div>

        <div class="tabs">
            <button class="tab-button active" onclick="openTab('dishes')">Dishes</button>
            <button class="tab-button" onclick="openTab('orders')">Order History</button>
            <button class="tab-button" onclick="openTab('feedback')">Feedback</button>
        </div>

        <!-- Dishes Tab -->
        <div id="dishes" class="tab-content active">
            <div class="filter-container">
                <input type="text" id="searchInput" placeholder="Search dishes...">
                <select id="categoryFilter">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $key => $label): ?>
                        <option value="<?php echo htmlspecialchars($key); ?>"><?php echo htmlspecialchars($label); ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="btn" onclick="openModal()">Add New Dish</button>
            </div>

            <div class="dish-grid" id="dishGrid"></div>

            <div class="pagination" id="pagination"></div>
        </div>

        <!-- Orders Tab -->
        <div id="orders" class="tab-content">
            <div class="order-grid" id="orderGrid"></div>
        </div>

        <!-- Feedback Tab -->
        <div id="feedback" class="tab-content">
            <div class="feedback-grid" id="feedbackGrid"></div>
        </div>
    </div>

    <!-- Modal for Add/Edit Dish -->
    <div id="dishModal" class="modal">
        <div class="modal-content">
            <h3 id="modalTitle">Add New Dish</h3>
            <form id="dishForm" enctype="multipart/form-data">
                <input type="hidden" name="id" id="dishId">
                <input type="hidden" name="action" value="save">
                <div class="form-group">
                    <label for="name">Dish Name</label>
                    <input type="text" name="name" id="name" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" id="description"></textarea>
                </div>
                <div class="form-group">
                    <label for="price">Price (৳)</label>
                    <input type="number" step="0.01" name="price" id="price" required>
                </div>
                <div class="form-group">
                    <label for="quantity">Quantity</label>
                    <input type="number" name="quantity" id="quantity" required>
                </div>
                <div class="form-group">
                    <label for="category">Category</label>
                    <select name="category" id="category" required>
                        <option value="">Select Category</option>
                        <?php foreach ($categories as $key => $label): ?>
                            <option value="<?php echo htmlspecialchars($key); ?>"><?php echo htmlspecialchars($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="preparation_time">Preparation Time (minutes)</label>
                    <input type="number" name="preparation_time" id="preparation_time" required>
                </div>
                <div class="form-group">
                    <label for="is_available">Availability</label>
                    <select name="is_available" id="is_available">
                        <option value="1">Available</option>
                        <option value="0">Not Available</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="image">Image</label>
                    <input type="file" name="image" id="image" accept="image/*">
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn">Save</button>
                    <button type="button" class="btn btn-dark" onclick="closeModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <footer>
        <p>Contact: 01515215020</p>
    </footer>

    <script>
        let currentPage = 1;

        function openTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
            document.getElementById(tabName).classList.add('active');
            document.querySelector(`.tab-button[onclick="openTab('${tabName}')"]`).classList.add('active');

            if (tabName === 'dishes') {
                loadDishes();
            } else if (tabName === 'orders') {
                loadOrders();
            } else if (tabName === 'feedback') {
                loadFeedback();
            }
        }

        function loadDishes() {
            const search = document.getElementById('searchInput').value;
            const category = document.getElementById('categoryFilter').value;
            fetch(`menu-management.php?action=list&page=${currentPage}&search=${encodeURIComponent(search)}&category=${encodeURIComponent(category)}`)
                .then(res => res.json())
                .then(data => {
                    const dishGrid = document.getElementById('dishGrid');
                    dishGrid.innerHTML = '';
                    if (data.error) {
                        dishGrid.innerHTML = `<p style="color: #dc3545; text-align: center;">${data.error}</p>`;
                        return;
                    }
                    if (data.dishes.length === 0) {
                        dishGrid.innerHTML = '<p style="color: #2e7d32; text-align: center;">No dishes found.</p>';
                        return;
                    }
                    data.dishes.forEach(dish => {
                        const card = document.createElement('div');
                        card.className = 'dish-card';
                        card.innerHTML = `
                            <div class="dish-image">
                                <img src="${dish.image ? '../Uploads/dishes/' + dish.image : '../assets/images/placeholder.jpg'}" alt="${dish.name}">
                            </div>
                            <div class="dish-content">
                                <h3>${dish.name}</h3>
                                <p>${dish.description || 'No description'}</p>
                                <p>Price: ৳${parseFloat(dish.price).toFixed(2)}</p>
                                <p>Quantity: ${dish.quantity}</p>
                                <p>Category: ${dish.category}</p>
                                <p>Prep Time: ${dish.preparation_time} mins</p>
                                <p>Status: ${dish.is_available ? 'Available' : 'Not Available'}</p>
                                <div class="dish-actions">
                                    <button class="btn" onclick="editDish(${dish.id})">Edit</button>
                                    <button class="btn btn-dark" onclick="deleteDish(${dish.id})">Delete</button>
                                </div>
                            </div>
                        `;
                        dishGrid.appendChild(card);
                    });

                    // Update pagination
                    const pagination = document.getElementById('pagination');
                    pagination.innerHTML = '';
                    if (data.totalPages > 1) {
                        const prev = document.createElement('button');
                        prev.textContent = 'Previous';
                        prev.disabled = currentPage === 1;
                        prev.onclick = () => { if (currentPage > 1) { currentPage--; loadDishes(); } };
                        pagination.appendChild(prev);

                        for (let i = 1; i <= data.totalPages; i++) {
                            const pageBtn = document.createElement('button');
                            pageBtn.textContent = i;
                            pageBtn.disabled = i === currentPage;
                            pageBtn.onclick = () => { currentPage = i; loadDishes(); };
                            pagination.appendChild(pageBtn);
                        }

                        const next = document.createElement('button');
                        next.textContent = 'Next';
                        next.disabled = currentPage === data.totalPages;
                        next.onclick = () => { if (currentPage < data.totalPages) { currentPage++; loadDishes(); } };
                        pagination.appendChild(next);
                    }
                })
                .catch(err => {
                    console.error('Error loading dishes:', err);
                    document.getElementById('dishGrid').innerHTML = '<p style="color: #dc3545; text-align: center;">Failed to load dishes.</p>';
                });
        }

        function loadOrders() {
            fetch('menu-management.php?action=order_history')
                .then(res => res.json())
                .then(data => {
                    const orderGrid = document.getElementById('orderGrid');
                    orderGrid.innerHTML = '';
                    if (data.error) {
                        orderGrid.innerHTML = `<p style="color: #dc3545; text-align: center;">${data.error}</p>`;
                        return;
                    }
                    if (data.orders.length === 0) {
                        orderGrid.innerHTML = '<p style="color: #2e7d32; text-align: center;">No orders found.</p>';
                        return;
                    }
                    const ordersById = {};
                    data.orders.forEach(order => {
                        if (!ordersById[order.id]) {
                            ordersById[order.id] = {
                                ...order,
                                items: []
                            };
                        }
                        ordersById[order.id].items.push({
                            food_name: order.food_name,
                            quantity: order.quantity,
                            price: order.price,
                            food_image: order.food_image
                        });
                    });
                    Object.values(ordersById).forEach(order => {
                        const card = document.createElement('div');
                        card.className = 'order-card';
                        const itemsHtml = order.items.map(item => `
                            <p>${item.food_name} x${item.quantity} - ৳${parseFloat(item.price).toFixed(2)}</p>
                        `).join('');
                        card.innerHTML = `
                            <div class="order-image">
                                <img src="${order.items[0].food_image ? '../Uploads/dishes/' + order.items[0].food_image : '../assets/images/placeholder.jpg'}" alt="Order Item">
                            </div>
                            <div class="order-content">
                                <h3>Order #${order.id}</h3>
                                <p>Customer: ${order.customer_name}</p>
                                <p>Total: ৳${parseFloat(order.total_amount).toFixed(2)}</p>
                                <p>Address: ${order.delivery_address}</p>
                                <p>Payment: ${order.payment_method} (${order.transaction_id})</p>
                                <p>Date: ${new Date(order.created_at).toLocaleString()}</p>
                                <div>Items: ${itemsHtml}</div>
                            </div>
                        `;
                        orderGrid.appendChild(card);
                    });
                })
                .catch(err => {
                    console.error('Error loading orders:', err);
                    document.getElementById('orderGrid').innerHTML = '<p style="color: #dc3545; text-align: center;">Failed to load orders.</p>';
                });
        }

        function loadFeedback() {
            fetch('menu-management.php?action=fetch_feedback')
                .then(res => res.json())
                .then(data => {
                    const feedbackGrid = document.getElementById('feedbackGrid');
                    feedbackGrid.innerHTML = '';
                    if (data.status === 'error') {
                        feedbackGrid.innerHTML = `<p style="color: #dc3545; text-align: center;">${data.message}</p>`;
                        return;
                    }
                    if (data.feedback.length === 0) {
                        feedbackGrid.innerHTML = '<p style="color: #2e7d32; text-align: center;">No feedback found.</p>';
                        return;
                    }
                    data.feedback.forEach(fb => {
                        const card = document.createElement('div');
                        card.className = 'feedback-card';
                        card.innerHTML = `
                            <div class="feedback-content">
                                <h3>Order #${fb.order_id}</h3>
                                <p>Customer: ${fb.customer_name}</p>
                                <p>Rating: ${'★'.repeat(fb.rating)}${'☆'.repeat(5 - fb.rating)}</p>
                                <p>Comment: ${fb.comment || 'No comment'}</p>
                                <p>Items: ${fb.item_names}</p>
                                <p>Date: ${new Date(fb.created_at).toLocaleString()}</p>
                            </div>
                        `;
                        feedbackGrid.appendChild(card);
                    });
                })
                .catch(err => {
                    console.error('Error loading feedback:', err);
                    document.getElementById('feedbackGrid').innerHTML = '<p style="color: #dc3545; text-align: center;">Failed to load feedback.</p>';
                });
        }

        function openModal() {
            document.getElementById('dishModal').classList.add('show');
            document.getElementById('modalTitle').textContent = 'Add New Dish';
            document.getElementById('dishForm').reset();
            document.getElementById('dishId').value = '';
        }

        function closeModal() {
            document.getElementById('dishModal').classList.remove('show');
        }

        function editDish(id) {
            fetch(`menu-management.php?id=${id}`)
                .then(res => res.json())
                .then(data => {
                    if (data.error) {
                        alert(data.error);
                        return;
                    }
                    document.getElementById('dishId').value = data.id;
                    document.getElementById('name').value = data.name;
                    document.getElementById('description').value = data.description || '';
                    document.getElementById('price').value = data.price;
                    document.getElementById('quantity').value = data.quantity;
                    document.getElementById('category').value = data.category;
                    document.getElementById('preparation_time').value = data.preparation_time;
                    document.getElementById('is_available').value = data.is_available;
                    document.getElementById('modalTitle').textContent = 'Edit Dish';
                    document.getElementById('dishModal').classList.add('show');
                })
                .catch(err => {
                    console.error('Error fetching dish:', err);
                    alert('Failed to load dish data.');
                });
        }

        function deleteDish(id) {
            if (confirm('Are you sure you want to delete this dish?')) {
                fetch('menu-management.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=delete&id=${id}`
                })
                    .then(res => res.json())
                    .then(data => {
                        alert(data.message);
                        if (data.status === 'success') {
                            loadDishes();
                        }
                    })
                    .catch(err => {
                        console.error('Error deleting dish:', err);
                        alert('Failed to delete dish.');
                    });
            }
        }

        document.getElementById('dishForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            fetch('menu-management.php', {
                method: 'POST',
                body: formData
            })
                .then(res => res.json())
                .then(data => {
                    alert(data.message);
                    if (data.status === 'success') {
                        closeModal();
                        loadDishes();
                    }
                })
                .catch(err => {
                    console.error('Error saving dish:', err);
                    alert('Failed to save dish.');
                });
        });

        document.getElementById('searchInput').addEventListener('input', () => {
            currentPage = 1;
            loadDishes();
        });

        document.getElementById('categoryFilter').addEventListener('change', () => {
            currentPage = 1;
            loadDishes();
        });

        // Initial load
        loadDishes();
    </script>
</body>
</html>