<?php
session_start();
if (isset($_SESSION['order_success'])) {
    echo '<p style="color: #2e7d32; text-align: center; font-size: 1.2em; margin-top: 20px;">' . htmlspecialchars($_SESSION['order_success']) . '</p>';
    unset($_SESSION['order_success']);
}

$pageTitle = 'Customer Dashboard';
$includeCart = true;

require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/db.php';

// Check if user is logged in and is a customer
if (!isLoggedIn() || !isUserType('customer')) {
    header('Location: login.php');
    exit;
}

// Get user data
$userId = $_SESSION['user_id'];
$user = getUserData($userId);

// Get Customer's profile image path
$profileImage = isset($_SESSION['profile_image']) && !empty($_SESSION['profile_image']) 
    ? '../Uploads/profiles/' . $_SESSION['profile_image'] 
    : '../assets/images/placeholder.jpg';

$customerName = $_SESSION['user_name'] ?? 'Customer';
$customerLocation = $_SESSION['user_location'] ?? '';

// Fetch all chefs
$chefs = $db->select("SELECT id, name FROM users WHERE user_type = ?", ['chef']);
if ($chefs === false) {
    $chefs = [];
}

// Fetch categories
$categories = getCategories();

// Fetch confirmed orders with item details for the customer
try {
    $confirmedOrders = $db->select(
        "SELECT o.id, o.total_amount, o.status, o.delivery_address, o.created_at 
         FROM orders o
         WHERE o.customer_id = ? AND o.status = 'confirmed'
         ORDER BY o.created_at DESC",
        [$userId]
    );
    if ($confirmedOrders === false) {
        $confirmedOrders = [];
    }
} catch (Exception $e) {
    error_log("Error fetching confirmed orders: " . $e->getMessage());
    $confirmedOrders = [];
}

// Fetch detailed order items for confirmed orders
$orderItems = [];
if (!empty($confirmedOrders)) {
    try {
        $orderIds = array_column($confirmedOrders, 'id');
        $items = $db->select(
            "SELECT oi.order_id, oi.food_item_id, oi.quantity, fi.name, fi.image 
             FROM order_items oi
             LEFT JOIN food_items fi ON oi.food_item_id = fi.id
             WHERE oi.order_id IN (" . implode(',', array_fill(0, count($orderIds), '?')) . ")",
            $orderIds
        );
        if ($items !== false) {
            foreach ($items as $item) {
                $orderItems[$item['order_id']][] = $item;
            }
        }
    } catch (Exception $e) {
        error_log("Error fetching order items: " . $e->getMessage());
    }
}

// Fetch cart items for the customer
try {
    $cartItems = $db->select(
        "SELECT c.id, c.quantity, c.added_at, fi.id as food_id, fi.name, fi.price, fi.image, u.name as chef_name
         FROM cart c
         JOIN food_items fi ON c.food_id = fi.id
         JOIN users u ON c.chef_id = u.id
         WHERE c.customer_id = ?",
        [$userId]
    );
    if ($cartItems === false) {
        $cartItems = [];
    }
} catch (Exception $e) {
    error_log("Error fetching cart items: " . $e->getMessage());
    $cartItems = [];
}

// AJAX: Handle "Add to Cart"
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_to_cart') {
    $foodId = isset($_POST['food_id']) ? (int)$_POST['food_id'] : 0;
    $chefId = isset($_POST['chef_id']) ? (int)$_POST['chef_id'] : 0;

    // Validate input
    if ($foodId <= 0 || $chefId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid food or chef ID']);
        exit;
    }

    try {
        // Check if the item already exists in the cart
        $existingItem = $db->select(
            "SELECT id, quantity FROM cart WHERE customer_id = ? AND food_id = ? AND chef_id = ?",
            [$userId, $foodId, $chefId]
        );

        if ($existingItem && count($existingItem) > 0) {
            // Update quantity if the item already exists
            $newQuantity = $existingItem[0]['quantity'] + 1;
            $db->update(
                "UPDATE cart SET quantity = ?, added_at = NOW() WHERE id = ?",
                [$newQuantity, $existingItem[0]['id']]
            );
        } else {
            // Insert new item into the cart
            $db->insert(
                "INSERT INTO cart (customer_id, food_id, chef_id, quantity, added_at) VALUES (?, ?, ?, 1, NOW())",
                [$userId, $foodId, $chefId]
            );
        }

        echo json_encode(['status' => 'success', 'message' => 'Item added to cart successfully']);
    } catch (Exception $e) {
        error_log("Error adding to cart: " . $e->getMessage());
        echo json_encode(['status' => 'error', 'message' => 'Error adding to cart']);
    }
    exit;
}

// AJAX: Fetch foods
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'fetch_foods') {
    $chefId = isset($_GET['chef_id']) ? (int)$_GET['chef_id'] : null;
    $category = isset($_GET['category']) ? sanitizeInput($_GET['category']) : '';
    $location = isset($_GET['location']) ? trim(sanitizeInput($_GET['location'])) : '';
    $limit = 12;

    $query = "SELECT f.*, u.name AS chef_name, COALESCE(u.location, 'Not specified') AS chef_location 
              FROM food_items f 
              JOIN users u ON f.chef_id = u.id 
              WHERE f.is_available = 1";
    $params = [];

    if ($chefId) {
        $query .= " AND f.chef_id = ?";
        $params[] = $chefId;
    } elseif ($location && $location !== '') {
        $query .= " AND LOWER(u.location) LIKE LOWER(?)";
        $params[] = "%$location%";
    }

    if ($category) {
        $query .= " AND f.category = ?";
        $params[] = $category;
    }

    $countQuery = "SELECT COUNT(*) as total 
                   FROM food_items f 
                   JOIN users u ON f.chef_id = u.id 
                   WHERE f.is_available = 1";
    $countParams = [];

    if ($chefId) {
        $countQuery .= " AND f.chef_id = ?";
        $countParams[] = $chefId;
    } elseif ($location && $location !== '') {
        $countQuery .= " AND LOWER(u.location) LIKE LOWER(?)";
        $countParams[] = "%$location%";
    }

    if ($category) {
        $countQuery .= " AND f.category = ?";
        $countParams[] = $category;
    }

    try {
        $totalResult = $db->select($countQuery, $countParams);
        $totalAvailableItems = $totalResult[0]['total'] ?? 0;

        if (!$chefId && !$category && !$location) {
            $query .= " ORDER BY RAND()";
        } else {
            $query .= " ORDER BY f.created_at DESC";
        }

        $query .= " LIMIT ?";
        $params[] = $limit;

        $foodItems = $db->select($query, $params);
        if ($foodItems === false) {
            echo json_encode(['status' => 'error', 'message' => 'Failed to fetch food items']);
            exit;
        }

        echo json_encode([
            'status' => 'success',
            'foods' => $foodItems,
            'total_items' => $totalAvailableItems
        ]);
    } catch (Exception $e) {
        error_log("Error fetching foods: " . $e->getMessage());
        echo json_encode(['status' => 'error', 'message' => 'Server error fetching food items']);
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - Homemade Food Delivery</title>
    <style>
        /* Existing styles unchanged */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0.5)), 
                        url('https://images.unsplash.com/photo-1504674900247-087ca5f5c2f0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1350&q=80') no-repeat center center fixed;
            background-size: cover;
            color: #333;
            line-height: 1.6;
            overflow-x: hidden;
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes scaleIn {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        header {
            background: linear-gradient(90deg, #2e7d32, #66bb6a);
            padding: 15px 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
            animation: fadeIn 0.8s ease-in-out;
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1300px;
            margin: 0 auto;
        }

        .logo {
            transition: transform 0.3s ease;
        }

        .logo:hover {
            transform: scale(1.05);
        }

        .logo img {
            height: 50px;
            filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
        }

        .search-bar {
            flex-grow: 1;
            margin: 0 30px;
        }

        .search-bar input {
            width: 100%;
            padding: 12px 20px;
            border: 1px solid #a5d6a7;
            border-radius: 30px;
            font-size: 1em;
            outline: none;
            background: #f1f8e9;
            transition: all 0.3s ease;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .search-bar input:focus {
            border-color: #388e3c;
            box-shadow: 0 0 8px rgba(56, 142, 60, 0.3);
            background: #fff;
        }

        .user {
            display: flex;
            align-items: center;
            gap: 15px;
            background: rgba(255, 255, 255, 0.2);
            padding: 8px 15px;
            border-radius: 30px;
            transition: all 0.3s ease;
        }

        .user:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.02);
        }

        .user img {
            height: 45px;
            width: 45px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #a5d6a7;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease;
        }

        .user img:hover {
            transform: rotate(10deg);
        }

        .user div {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }

        .user div strong {
            font-size: 1.1em;
            color: #fff;
            font-weight: 500;
        }

        .user div span {
            font-size: 0.9em;
            color: #f5f5f5;
        }

        .btn {
            padding: 10px 20px;
            background: linear-gradient(45deg, #2e7d32, #66bb6a);
            color: #fff;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 0.95em;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
        }

        .btn:hover {
            background: linear-gradient(45deg, #66bb6a, #2e7d32);
            transform: translateY(-2px);
            box-shadow: 0 5px 12px rgba(0, 0, 0, 0.2);
            animation: pulse 0.5s infinite;
        }

        .btn-dark {
            background: linear-gradient(45deg, #dc3545, #e74c3c);
        }

        .btn-dark:hover {
            background: linear-gradient(45deg, #e74c3c, #dc3545);
            transform: translateY(-2px);
            box-shadow: 0 5px 12px rgba(0, 0, 0, 0.2);
            animation: pulse 0.5s infinite;
        }

        .main-container {
            display: flex;
            max-width: 1300px;
            margin: 30px auto;
            gap: 30px;
        }

        .sidebar {
            width: 280px;
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            padding: 25px;
            animation: slideUp 0.5s ease-in-out;
            border: 1px solid #a5d6a7;
            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40"><path d="M20 5c-5 0-9 4-9 9s4 9 9 9 9-4 9-9-4-9-9-9zm0 2c3.9 0 7 3.1 7 7s-3.1 7-7 7-7-3.1-7-7 3.1-7 7-7zm-1 2c-1.7 0-3 1.3-3 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3z" fill="%2366bb6a" fill-opacity="0.1"/></svg>');
        }

        .sidebar h3 {
            font-size: 1.8em;
            color: #2e7d32;
            margin-bottom: 20px;
            font-weight: 600;
            position: relative;
        }

        .sidebar h3::after {
            content: '';
            width: 50px;
            height: 3px;
            background: linear-gradient(90deg, #2e7d32, #66bb6a);
            position: absolute;
            bottom: -5px;
            left: 0;
            border-radius: 2px;
        }

        .chef-select {
            width: 100%;
            padding: 12px;
            border: 1px solid #a5d6a7;
            border-radius: 8px;
            font-size: 1em;
            color: #2d3436;
            background: #f1f8e9 url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12"><path d="M6 9l-4-4h8z" fill="%232e7d32"/></svg>') no-repeat right 10px center;
            appearance: none;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .chef-select:focus {
            border-color: #388e3c;
            box-shadow: 0 0 8px rgba(56, 142, 60, 0.3);
            background: #fff;
            outline: none;
        }

        .chef-select option {
            padding: 10px;
            background: #fff;
            color: #2d3436;
        }

        .filter-container {
            background: #fff;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-bottom: 25px;
            display: flex;
            gap: 20px;
            align-items: center;
            animation: slideUp 0.5s ease-in-out;
            border: 1px solid #a5d6a7;
            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40"><path d="M20 5c-5 0-9 4-9 9s4 9 9 9 9-4 9-9-4-9-9-9zm0 2c3.9 0 7 3.1 7 7s-3.1 7-7 7-7-3.1-7-7 3.1-7 7-7zm-1 2c-1.7 0-3 1.3-3 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3z" fill="%2366bb6a" fill-opacity="0.1"/></svg>');
        }

        .filter-container label {
            font-size: 1em;
            color: #2e7d32;
            font-weight: 500;
        }

        .filter-container select {
            padding: 10px;
            border: 1px solid #a5d6a7;
            border-radius: 8px;
            font-size: 0.95em;
            outline: none;
            background: #f1f8e9 url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12"><path d="M6 9l-4-4h8z" fill="%232e7d32"/></svg>') no-repeat right 10px center;
            transition: all 0.3s ease;
            flex: 1;
            appearance: none;
        }

        .filter-container select:focus {
            border-color: #388e3c;
            box-shadow: 0 0 8px rgba(56, 142, 60, 0.3);
            background: #fff;
        }

        .filter-container input[type="text"] {
            padding: 10px;
            border: 1px solid #a5d6a7;
            border-radius: 8px;
            font-size: 0.95em;
            outline: none;
            background: #f1f8e9;
            transition: all 0.3s ease;
            flex: 1;
        }

        .filter-container input[type="text"]:focus {
            border-color: #388e3c;
            box-shadow: 0 0 8px rgba(56, 142, 60, 0.3);
            background: #fff;
        }

        .location-toggle {
            padding: 8px 16px;
            background: linear-gradient(45deg, #388e3c, #a5d6a7);
            color: #fff;
            border: none;
            border-radius: 25px;
            font-size: 0.9em;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .location-toggle:hover {
            background: linear-gradient(45deg, #a5d6a7, #388e3c);
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
        }

        .available-items {
            background: #fff;
            padding: 10px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            text-align: center;
            font-size: 1.1em;
            color: #2e7d32;
            font-weight: 500;
            border: 1px solid #a5d6a7;
            animation: slideUp 0.5s ease-in-out;
        }

        .content {
            flex: 1;
        }

        .section-title {
            text-align: center;
            margin-bottom: 40px;
            animation: fadeIn 1s ease-in-out;
        }

        .section-title h2 {
            font-size: 2.5em;
            color: #2e7d32;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
        }

        .section-title h2::after {
            content: '';
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, #2e7d32, #66bb6a);
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            border-radius: 2px;
        }

        .food-grid, .order-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
        }

        .food-card, .order-card {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            overflow: hidden;
            border: 1px solid #a5d6a7;
            animation: slideUp 0.5s ease forwards;
            animation-delay: calc(var(--delay) * 0.1s);
            background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40"><path d="M20 5c-5 0-9 4-9 9s4 9 9 9 9-4 9-9-4-9-9-9zm0 2c3.9 0 7 3.1 7 7s-3.1 7-7 7-7-3.1-7-7 3.1-7 7-7zm-1 2c-1.7 0-3 1.3-3 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3z" fill="%2366bb6a" fill-opacity="0.1"/></svg>');
        }

        .food-card::before, .order-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #2e7d32, #66bb6a);
            transition: all 0.3s ease;
        }

        .food-card:hover, .order-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
            border-color: #388e3c;
        }

        .food-card:hover::before, .order-card:hover::before {
            height: 100%;
            opacity: 0.1;
        }

        .food-card-image {
            height: 200px;
            overflow: hidden;
            position: relative;
        }

        .food-card-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .food-card:hover .food-card-image img {
            transform: scale(1.1);
        }

        .food-card-content, .order-card-content {
            padding: 20px;
        }

        .food-card-title, .order-card-title {
            font-size: 1.5em;
            color: #2d3436;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .food-card-chef {
            color: #636e72;
            font-size: 0.95em;
            margin-bottom: 8px;
        }

        .food-card-location {
            color: #636e72;
            font-size: 0.85em;
            margin-bottom: 12px;
            font-style: italic;
        }

        .food-card-meta, .order-card-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .food-card-price, .order-card-price {
            font-weight: bold;
            color: #388e3c;
            font-size: 1.2em;
        }

        .food-card-time {
            color: #636e72;
            font-size: 0.95em;
        }

        .order-card-items {
            color: #636e72;
            font-size: 0.95em;
            margin-bottom: 12px;
        }

        .order-card-address, .order-card-date {
            color: #636e72;
            font-size: 0.9em;
            margin-bottom: 8px;
        }

        .add-to-cart {
            width: 100%;
            padding: 12px;
            background: linear-gradient(45deg, #2e7d32, #66bb6a);
            color: #fff;
            border: none;
            border-radius: 25px;
            font-size: 1em;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
        }

        .add-to-cart:hover {
            background: linear-gradient(45deg, #66bb6a, #2e7d32);
            transform: translateY(-2px);
            box-shadow: 0 5px 12px rgba(0, 0, 0, 0.2);
            animation: pulse 0.5s infinite;
        }

        .proceed-to-payment, .feedback-btn {
            display: inline-block;
            padding: 10px 20px;
            background: linear-gradient(45deg, #2e7d32, #66bb6a);
            color: #fff;
            border: none;
            border-radius: 25px;
            font-size: 0.95em;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
            cursor: pointer;
        }

        .proceed-to-payment:hover, .feedback-btn:hover {
            background: linear-gradient(45deg, #66bb6a, #2e7d32);
            transform: translateY(-2px);
            box-shadow: 0 5px 12px rgba(0, 0, 0, 0.2);
            animation: pulse 0.5s infinite;
        }

        .feedback-btn:disabled {
            background: #dfe6e9;
            color: #b2bec3;
            cursor: not-allowed;
            box-shadow: none;
        }

        .cart-item-image, .order-card-image {
            height: 150px;
            overflow: hidden;
            position: relative;
            margin-bottom: 15px;
        }

        .cart-item-image img, .order-card-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .order-history-section {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 40px;
            border: 1px solid #a5d6a7;
        }

        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .tab-button {
            padding: 10px 20px;
            background: #e0e0e0;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .tab-button.active {
            background: #2e7d32;
            color: #fff;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        .cart-item {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            display: grid;
            gap: 10px;
        }

        .cart-item h3 {
            color: #2e7d32;
            font-size: 1.2em;
        }

        .cart-item p {
            margin: 5px 0;
            color: #666;
        }

        .cart-item .total {
            font-weight: bold;
            color: #388e3c;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            z-index: 1000;
            animation: fadeIn 0.5s ease-in-out;
        }

        .modal.show {
            display: flex;
        }

        .modal-content {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            animation: scaleIn 0.3s ease-in-out;
            border: 1px solid #66bb6a;
        }

        .modal-content h3 {
            color: #2e7d32;
            font-weight: 600;
            margin-bottom: 20px;
            text-align: center;
        }

        .feedback-form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .feedback-form label {
            color: #2e7d32;
            font-weight: 500;
        }

        .feedback-form input, .feedback-form textarea {
            padding: 12px;
            border: 1px solid #a5d6a7;
            border-radius: 8px;
            font-size: 0.95em;
            background: #f1f8e9;
            transition: all 0.3s ease;
        }

        .feedback-form input:focus, .feedback-form textarea:focus {
            border-color: #388e3c;
            box-shadow: 0 0 8px rgba(56, 142, 60, 0.3);
            background: #fff;
            outline: none;
        }

        .form-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .form-actions button {
            padding: 12px 25px;
            border-radius: 25px;
            font-size: 1em;
        }

        .form-actions button.cancel-btn {
            background: linear-gradient(45deg, #dfe6e9, #b2bec3);
            color: #2d3436;
        }

        .form-actions button.cancel-btn:hover {
            background: linear-gradient(45deg, #b2bec3, #dfe6e9);
            transform: translateY(-2px);
            box-shadow: 0 5px 12px rgba(0, 0, 0, 0.2);
        }

        footer {
            background: linear-gradient(90deg, #2e7d32, #66bb6a);
            color: #fff;
            padding: 40px 20px;
            margin-top: 60px;
            text-align: center;
            animation: fadeIn 1s ease-in-out;
        }

        .footer-content {
            max-width: 1300px;
            margin: 0 auto;
        }

        .footer-logo img {
            height: 40px;
            margin-bottom: 15px;
            filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
        }

        .footer-text {
            color: #f1f8e9;
            margin-bottom: 20px;
            font-size: 1.1em;
        }

        .footer-social a {
            color: #fff;
            margin: 0 15px;
            font-size: 1.5em;
            transition: all 0.3s ease;
        }

        .footer-social a:hover {
            color: #a5d6a7;
            transform: scale(1.2);
        }

        .footer-contact {
            margin-top: 15px;
            color: #f1f8e9;
            font-size: 1em;
        }

        @media (max-width: 768px) {
            .header-container {
                flex-direction: column;
                gap: 15px;
            }

            .search-bar {
                margin: 0;
                width: 100%;
            }

            .user {
                width: 100%;
                justify-content: center;
            }

            .main-container {
                flex-direction: column;
                margin: 20px;
            }

            .sidebar {
                width: 100%;
            }

            .filter-container {
                flex-direction: column;
                align-items: stretch;
                padding: 15px;
            }

            .food-grid, .order-grid {
                grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            }

            .tabs {
                flex-direction: column;
            }

            .tab-button {
                width: 100%;
                text-align: left;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <a href="../index.php">
                    <img src="../assets/images/logo.png" alt="Homemade Food Delivery">
                </a>
            </div>
            
            <div class="search-bar">
                <input type="text" placeholder="Enter item or Home you are looking for">
            </div>
            
            <div class="user">
                <img src="<?php echo htmlspecialchars($profileImage); ?>" alt="<?php echo htmlspecialchars($customerName); ?>">
                <div>
                    <strong><?php echo htmlspecialchars($customerName); ?></strong>
                    <span><?php echo htmlspecialchars($customerLocation); ?></span>
                </div>
                <button class="btn" onclick="toggleOrderHistory()">Order History</button>
                <a href="../logout.php" class="btn btn-dark">Log Out</a>
            </div>
        </div>
    </header>

    <div class="main-container">
        <div class="sidebar">
            <h3>Chefs</h3>
            <select class="chef-select" id="chefSelect" onchange="selectChef(this.value)">
                <option value="0">All Chefs</option>
                <?php foreach ($chefs as $chef): ?>
                    <option value="<?php echo $chef['id']; ?>"><?php echo htmlspecialchars($chef['name']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="content">
            <div id="orderHistorySection" class="order-history-section" style="display: none;">
                <div class="section-title">
                    <h2>Your Order History</h2>
                </div>
                <div class="tabs">
                    <button class="tab-button active" onclick="openTab('cart')">Cart Items</button>
                    <button class="tab-button" onclick="openTab('confirmed')">Confirmed Orders</button>
                </div>

                <div id="cart" class="tab-content active">
                    <?php if (empty($cartItems)): ?>
                        <p style="text-align: center; color: #2e7d32; font-weight: 500;">No items in your cart.</p>
                    <?php else: ?>
                        <?php foreach ($cartItems as $item): ?>
                            <div class="cart-item">
                                <div class="cart-item-image">
                                    <img src="<?php echo htmlspecialchars(!empty($item['image']) ? '../Uploads/dishes/' . $item['image'] : '../assets/images/placeholder.jpg'); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                                </div>
                                <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                <p>Chef: <?php echo htmlspecialchars($item['chef_name']); ?></p>
                                <p>Quantity: <?php echo htmlspecialchars($item['quantity']); ?></p>
                                <p>Price: ৳<?php echo number_format($item['price'], 2); ?></p>
                                <p>Added On: <?php echo htmlspecialchars(date('d M Y, H:i', strtotime($item['added_at']))); ?></p>
                                <button class="proceed-to-payment" onclick="proceedToPayment(<?php echo $item['id']; ?>, '<?php echo htmlspecialchars($item['name']); ?>', <?php echo $item['price']; ?>, '<?php echo htmlspecialchars($item['image'] ?? ''); ?>', <?php echo $item['food_id']; ?>, <?php echo $item['quantity']; ?>)">Proceed to Payment</button>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div id="confirmed" class="tab-content">
                    <?php if (empty($confirmedOrders)): ?>
                        <p style="text-align: center; grid-column: 1 / -1; color: #2e7d32; font-weight: 500;">No confirmed orders yet.</p>
                    <?php else: ?>
                        <div class="order-grid" id="orderGrid">
                            <?php foreach ($confirmedOrders as $index => $order): ?>
                                <?php
                                $items = $orderItems[$order['id']] ?? [];
                                $itemsList = '';
                                foreach ($items as $item) {
                                    $itemsList .= htmlspecialchars($item['name'] ?? 'Unknown Item') . ' (Qty: ' . htmlspecialchars($item['quantity'] ?? 0) . '), ';
                                }
                                $itemsList = rtrim($itemsList, ', ') ?: 'N/A';
                                $displayImage = !empty($items) && !empty($items[0]['image']) 
                                    ? '../Uploads/dishes/' . htmlspecialchars($items[0]['image']) 
                                    : '../assets/images/placeholder.jpg';
                                $displayName = !empty($items) && !empty($items[0]['name']) 
                                    ? htmlspecialchars($items[0]['name']) 
                                    : 'Order Image';
                                ?>
                                <div class="order-card" style="--delay: <?php echo $index; ?>">
                                    <div class="order-card-content">
                                        <h3 class="order-card-title">Order #<?php echo htmlspecialchars($order['id']); ?></h3>
                                        <div class="order-card-image">
                                            <img src="<?php echo $displayImage; ?>" alt="<?php echo $displayName; ?>">
                                        </div>
                                        <p class="order-card-items">Items: <?php echo $itemsList; ?></p>
                                        <p class="order-card-address">Delivery Address: <?php echo htmlspecialchars($order['delivery_address']); ?></p>
                                        <p class="order-card-date">Ordered On: <?php echo htmlspecialchars(date('d M Y, H:i', strtotime($order['created_at']))); ?></p>
                                        <div class="order-card-meta">
                                            <div class="order-card-price">৳<?php echo number_format($order['total_amount'], 2); ?></div>
                                            <button class="feedback-btn" data-order-id="<?php echo $order['id']; ?>" disabled>Give Feedback</button>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="available-items" id="availableItems">
                Total Available Items: <span id="totalItemsCount">0</span>
            </div>

            <div class="filter-container">
                <label for="categorySelect">Filter by Category:</label>
                <select id="categorySelect">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $key => $label): ?>
                        <option value="<?php echo htmlspecialchars($key); ?>"><?php echo htmlspecialchars($label); ?></option>
                    <?php endforeach; ?>
                </select>

                <button id="locationToggle" class="location-toggle" onclick="toggleLocationInput()">
                    Use Custom Location
                </button>
                
                <div id="locationInputContainer" style="display: none; flex: 1;">
                    <label for="locationInput">Custom Location:</label>
                    <input type="text" id="locationInput" placeholder="Enter a location">
                </div>
            </div>

            <div class="section-title">
                <h2>Explore Homemade Foods</h2>
            </div>

            <div class="food-grid" id="foodGrid"></div>
        </div>
    </div>

    <!-- Feedback Modal -->
    <div id="feedbackModal" class="modal">
        <div class="modal-content">
            <h3>Submit Feedback</h3>
            <form id="feedbackForm" class="feedback-form">
                <input type="hidden" name="order_id">
                <div>
                    <label for="rating">Rating (1-5):</label>
                    <input type="number" name="rating" min="1" max="5" required>
                </div>
                <div>
                    <label for="comment">Comment:</label>
                    <textarea name="comment" rows="4" placeholder="Your feedback..."></textarea>
                </div>
                <div class="form-actions">
                    <button type="submit">Submit</button>
                    <button type="button" class="cancel-btn" onclick="closeFeedbackModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <div class="footer-logo">
                <img src="../assets/images/logo.png" alt="Homemade Food Delivery">
            </div>
            <p class="footer-text">Your Favorite Food, Delivered! 🍲🍽️</p>
            <div class="footer-social">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
            </div>
            <div class="footer-contact">
                <p>Contact: 01515215020</p>
            </div>
        </div>
    </footer>

    <script>
        let selectedChefId = 0;
        let useCustomLocation = false;
        const customerLocation = "<?php echo htmlspecialchars($customerLocation); ?>";

        function toggleOrderHistory() {
            const orderHistorySection = document.getElementById('orderHistorySection');
            orderHistorySection.style.display = orderHistorySection.style.display === 'none' ? 'block' : 'none';
            if (orderHistorySection.style.display === 'block' && document.getElementById('confirmed').classList.contains('active')) {
                checkFeedbackStatus();
            }
        }

        function openTab(tabName) {
            document.getElementById('cart').classList.toggle('active', tabName === 'cart');
            document.getElementById('confirmed').classList.toggle('active', tabName === 'confirmed');
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.toggle('active', btn.textContent.trim() === (tabName === 'cart' ? 'Cart Items' : 'Confirmed Orders'));
            });
            if (tabName === 'confirmed') {
                checkFeedbackStatus();
            }
        }

        function toggleLocationInput() {
            useCustomLocation = !useCustomLocation;
            const locationInputContainer = document.getElementById('locationInputContainer');
            const locationToggle = document.getElementById('locationToggle');

            if (useCustomLocation) {
                locationInputContainer.style.display = 'flex';
                locationToggle.textContent = 'Use Registered Location';
                document.getElementById('locationInput').focus();
            } else {
                locationInputContainer.style.display = 'none';
                locationToggle.textContent = 'Use Custom Location';
                document.getElementById('locationInput').value = '';
            }

            loadFoods();
        }

        function selectChef(chefId) {
            selectedChefId = parseInt(chefId);
            document.getElementById('chefSelect').value = chefId;
            loadFoods();
        }

        function loadFoods() {
            const category = document.getElementById('categorySelect').value;
            let location = '';

            if (useCustomLocation) {
                location = document.getElementById('locationInput').value.trim();
                if (!location) {
                    location = '';
                }
            } else if (customerLocation && customerLocation.trim() !== '' && selectedChefId === 0) {
                location = customerLocation.trim();
            }

            const params = new URLSearchParams({
                action: 'fetch_foods',
                chef_id: selectedChefId,
                category: category,
                location: location
            });

            fetch(`dashboard.php?${params.toString()}`)
                .then(res => {
                    if (!res.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return res.json();
                })
                .then(data => {
                    if (data.status === 'error') {
                        throw new Error(data.message);
                    }

                    const foodGrid = document.getElementById('foodGrid');
                    foodGrid.innerHTML = '';

                    const totalItemsCount = document.getElementById('totalItemsCount');
                    totalItemsCount.textContent = data.total_items || 0;

                    if (!data.foods || data.foods.length === 0) {
                        foodGrid.innerHTML = '<p style="text-align: center; grid-column: 1 / -1; color: #2e7d32; font-weight: 500;">No food items available.</p>';
                        return;
                    }

                    data.foods.forEach((item, index) => {
                        const card = document.createElement('div');
                        card.className = 'food-card';
                        card.style.setProperty('--delay', index);
                        let cardContent = `
                            <div class="food-card-image">
                                <img src="${item.image ? '../Uploads/dishes/' + item.image : '../assets/images/placeholder.jpg'}" alt="${item.name}">
                            </div>
                            <div class="food-card-content">
                                <h3 class="food-card-title">${item.name}</h3>
                                <p class="food-card-chef">By ${item.chef_name}</p>
                        `;

                        if (selectedChefId === 0 || (useCustomLocation && location)) {
                            cardContent += `
                                <p class="food-card-location">Location: ${item.chef_location}</p>
                            `;
                        }

                        if (selectedChefId === 0) {
                            cardContent += `
                                <div class="food-card-meta">
                                    <div class="food-card-price">৳${parseFloat(item.price).toFixed(2)}</div>
                                    <div class="food-card-time">${item.preparation_time} Mins</div>
                                </div>
                            `;
                        } else {
                            cardContent += `
                                <div class="food-card-meta">
                                    <div class="food-card-price">৳${parseFloat(item.price).toFixed(2)}</div>
                                </div>
                            `;
                        }

                        cardContent += `
                                <button class="add-to-cart" 
                                    data-id="${item.id}" 
                                    data-name="${item.name}" 
                                    data-price="${item.price}" 
                                    data-image="${item.image ? '../Uploads/dishes/' + item.image : '../assets/images/placeholder.jpg'}"
                                    data-chef="${item.chef_id}">
                                    Add To Cart
                                </button>
                            </div>
                        `;
                        card.innerHTML = cardContent;
                        foodGrid.appendChild(card);
                    });

                    attachAddToCartListeners();
                })
                .catch(err => {
                    console.error('Error loading foods:', err);
                    document.getElementById('foodGrid').innerHTML = 
                        '<p style="text-align: center; grid-column: 1 / -1; color: #dc3545; font-weight: 500;">Error loading food items. Please try again later.</p>';
                });
        }

        function attachAddToCartListeners() {
            document.querySelectorAll('.add-to-cart').forEach(button => {
                button.addEventListener('click', () => {
                    const foodId = button.dataset.id;
                    const name = button.dataset.name;
                    const price = button.dataset.price;
                    const image = button.dataset.image;
                    const chefId = button.dataset.chef;

                    const params = new URLSearchParams({
                        action: 'add_to_cart',
                        food_id: foodId,
                        chef_id: chefId
                    });

                    fetch('dashboard.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: params.toString()
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(result => {
                        if (result.status === 'success') {
                            alert(result.message);
                            // Show the cart section and refresh it
                            const orderHistorySection = document.getElementById('orderHistorySection');
                            if (orderHistorySection.style.display !== 'block') {
                                toggleOrderHistory();
                            }
                            // Ensure the cart tab is active
                            if (!document.getElementById('cart').classList.contains('active')) {
                                openTab('cart');
                            }
                            // Refresh the page to update the cart items
                            window.location.reload();
                        } else {
                            alert(result.message || 'Error adding to cart');
                        }
                    })
                    .catch(error => {
                        console.error('Error adding to cart:', error);
                        alert('Error adding to cart. Please try again.');
                    });
                });
            });
        }

        function proceedToPayment(cartItemId, name, price, image, foodId, quantity) {
            window.location.href = `make_payment.php?cart_item_id=${cartItemId}&name=${encodeURIComponent(name)}&price=${price}&image=${encodeURIComponent(image)}&food_id=${foodId}&quantity=${quantity}`;
        }

        function openFeedbackModal(orderId) {
            const form = document.getElementById('feedbackForm');
            form.reset();
            form.order_id.value = orderId;
            document.getElementById('feedbackModal').classList.add('show');
        }

        function closeFeedbackModal() {
            document.getElementById('feedbackModal').classList.remove('show');
        }

        function checkFeedbackStatus() {
            document.querySelectorAll('.feedback-btn').forEach(button => {
                const orderId = button.dataset.orderId;
                fetch(`feedback.php?action=check_feedback&order_id=${orderId}`)
                    .then(res => {
                        if (!res.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return res.json();
                    })
                    .then(data => {
                        if (data.status === 'success') {
                            button.disabled = data.has_feedback;
                            button.textContent = data.has_feedback ? 'Feedback Submitted' : 'Give Feedback';
                            if (!data.has_feedback) {
                                button.onclick = () => openFeedbackModal(orderId);
                            }
                        } else {
                            console.error('Error checking feedback:', data.message);
                            button.disabled = true;
                            button.textContent = 'Error';
                        }
                    })
                    .catch(err => {
                        console.error('Error checking feedback status:', err);
                        button.disabled = true;
                        button.textContent = 'Error';
                    });
            });
        }

        document.getElementById('feedbackForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            formData.append('action', 'submit_feedback');

            fetch('feedback.php', {
                method: 'POST',
                body: formData
            })
            .then(res => {
                if (!res.ok) {
                    throw new Error('Network response was not ok');
                }
                return res.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    closeFeedbackModal();
                    checkFeedbackStatus();
                    alert(data.message);
                } else {
                    alert(data.message || 'Error submitting feedback');
                }
            })
            .catch(err => {
                console.error('Error submitting feedback:', err);
                alert('Error submitting feedback. Please try again.');
            });
        });

        document.addEventListener('DOMContentLoaded', () => {
            loadFoods();
        });

        document.getElementById('categorySelect').addEventListener('change', () => {
            loadFoods();
        });

        document.getElementById('locationInput')?.addEventListener('input', () => {
            loadFoods();
        });
    </script>
</body>
</html>