<?php
require_once 'includes/header.php';
?>

<style>
/* Reset and Base Styles */
* {

    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    background-color: #E6ECF4;
    color: #1A2A44;
    line-height: 1.7;
    overflow-x: hidden;
}

/* Container */
.container {
    max-width: 1240px;
    margin: 0 auto;
    padding: 0 24px;
}

/* Hero Section */
.hero {
    background: linear-gradient(135deg, #1C315E 0%, #4B6FEF 100%);
    color: #FFFFFF;
    padding: 120px 0;
    text-align: center;
    position: relative;
    border-bottom: 6px solid #3B5ACF;
}

.hero h1 {
    font-size: 3.5rem;
    font-weight: 800;
    margin-bottom: 1.2rem;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    color: #FFFFFF; /* Explicitly set to white */
}

.hero p {
    font-size: 1.4rem;
    margin-bottom: 2.5rem;
    opacity: 0.95;
    max-width: 600px;
    margin-left: auto;
    margin-right: auto;
    color: #FFFFFF; /* Explicitly set to white */
}

.hero .btn {
    display: inline-block;
    background-color: #FFD700;
    color: #1A2A44;
    padding: 14px 32px;
    font-size: 1.2rem;
    font-weight: 700;
    text-decoration: none;
    border-radius: 10px;
    transition: background-color 0.3s, transform 0.2s, box-shadow 0.3s;
    margin: 0 12px;
}

.hero .btn:hover {
    background-color: #FFC107;
    transform: translateY(-3px);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
}

.hero .btn.secondary {
    background-color: transparent;
    border: 2px solid #FFFFFF;
    color: #FFFFFF;
}

.hero .btn.secondary:hover {
    background-color: #FFFFFF;
    color: #1A2A44;
    border-color: #FFFFFF;
}

/* Food Animation in Top-Right */
.food-animation {
    position: absolute;
    top: 20px;
    right: 20px;
    width: 150px;
    height: 150px;
    overflow: hidden;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    z-index: 10;
}

.food-animation img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    position: absolute;
    top: 0;
    left: 0;
    opacity: 0;
    animation: fade 9s infinite;
}

.food-animation img:nth-child(1) { animation-delay: 0s; }
.food-animation img:nth-child(2) { animation-delay: 3s; }
.food-animation img:nth-child(3) { animation-delay: 6s; }

@keyframes fade {
    0% { opacity: 0; }
    11.11% { opacity: 1; }
    33.33% { opacity: 1; }
    44.44% { opacity: 0; }
    100% { opacity: 0; }
}

/* Section Styles */
.section {
    padding: 80px 0;
    background-color: #FFFFFF;
    border-radius: 16px;
    margin: 50px 0;
    box-shadow: 0 6px 25px rgba(0, 0, 0, 0.08);
    position: relative;
    overflow: hidden;
}

/* Add a subtle background texture to sections */
.section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAAXNSR0IArs4c6QAAAB9JREFUeF7tzrENgCAMQ9G49x+0t7e30J4eUvsG8QUc5dIAvOENhAAAAAElFTkSuQmCC') repeat;
    opacity: 0.05;
    z-index: 0;
}

.section > * {
    position: relative;
    z-index: 1;
}

.section-title, .st {
    font-size: 2.5rem;
    font-weight: 800;
    color: #1A2A44;
    text-align: center;
    margin-bottom: 48px;
    position: relative;
}

.section-title::after, .st::after {
    content: '';
    width: 80px;
    height: 4px;
    background: linear-gradient(90deg, #FFD700, #FFC107);
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    border-radius: 2px;
}

/* Food Grid */
.food-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 32px;
}

/* Enhanced Card Styles for Top Selling Items */
.card {
    --card-hue: 40; /* Base hue for color variation */
    background: linear-gradient(145deg, #FFFFFF, #F9FBFF);
    border-radius: 20px;
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease, rotate 0.3s ease;
    border: 1px solid #DDE4EE;
    position: relative;
    animation: slideUp 0.8s ease-out forwards;
}

/* Color variation for each card */
.card:nth-child(1) { --card-hue: 0; }   /* Red */
.card:nth-child(2) { --card-hue: 40; }  /* Orange */
.card:nth-child(3) { --card-hue: 90; }  /* Green */
.card:nth-child(4) { --card-hue: 200; } /* Cyan */
.card:nth-child(5) { --card-hue: 270; } /* Purple */
.card:nth-child(6) { --card-hue: 320; } /* Pink */

.card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 5px;
    background: linear-gradient(90deg, hsl(var(--card-hue), 80%, 60%), hsl(var(--card-hue), 80%, 50%));
    transition: height 0.3s ease;
}

.card:hover {
    transform: translateY(-12px) rotate(2deg);
    box-shadow: 0 12px 35px rgba(0, 0, 0, 0.15);
}

.card:hover::before {
    height: 100%;
    opacity: 0.05;
}

/* Colorful Placeholder Design */
.card-placeholder {
    position: relative;
    height: 240px;
    background: linear-gradient(135deg, hsl(var(--card-hue), 80%, 60%), hsl(var(--card-hue), 80%, 40%));
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    animation: pulseGlow 2s infinite ease-in-out;
}

.card-placeholder::after {
    content: '🍽️';
    font-size: 5rem;
    opacity: 0.3;
    position: absolute;
    color: #FFFFFF;
    text-shadow: 0 3px 6px rgba(0, 0, 0, 0.3);
}

.card-placeholder::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.3), rgba(0, 0, 0, 0.2));
    pointer-events: none;
}

/* Pulsing Glow Animation for Placeholder */
@keyframes pulseGlow {
    0% { box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
    50% { box-shadow: 0 0 20px hsl(var(--card-hue), 80%, 50%); }
    100% { box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
}

.card-content {
    padding: 32px;
    background: rgba(255, 255, 255, 0.95);
    text-align: left;
}

.food-name {
    font-size: 1.9rem;
    font-weight: 800;
    color: #1A2A44;
    margin-bottom: 14px;
    text-transform: capitalize;
    display: flex;
    align-items: center;
    gap: 10px;
    letter-spacing: 0.5px;
}

.food-name::before {
    content: '🍴';
    font-size: 1.3rem;
    color: hsl(var(--card-hue), 80%, 50%);
}

.chef-info, .location-info, .cuisine {
    font-size: 1.15rem;
    color: #5A6A88;
    font-weight: 500;
    background: #E6ECF4;
    padding: 6px 14px;
    border-radius: 12px;
    display: inline-block;
    margin: 4px 0;
    transition: background-color 0.3s;
}

.chef-info:hover, .location-info:hover, .cuisine:hover {
    background-color: #DDE4EE;
}

.cuisine-rating {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 16px 0;
}

.rating {
    display: flex;
    align-items: center;
    gap: 8px;
    justify-content: flex-end;
}

.star {
    color: #FFB300;
    font-size: 1.4rem;
    animation: pulseStar 1.5s infinite;
}

@keyframes pulseStar {
    0% { transform: scale(1); }
    50% { transform: scale(1.2); }
    100% { transform: scale(1); }
}

.rating-value {
    font-size: 1.15rem;
    font-weight: 700;
    color: #1A2A44;
}

.card-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 18px;
    border-top: 1px solid #DDE4EE;
}

.time, .price {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 1.1rem;
    color: #5A6A88;
    font-weight: 500;
}

.time i, .price i {
    color: hsl(var(--card-hue), 80%, 50%);
    font-size: 1.2rem;
}

.time span, .price span {
    font-weight: 600;
    color: #1A2A44;
}

/* Testimonial Section */
.testimonial-section {
    background-color: #1C315E;
    color: #FFFFFF;
    padding: 80px 0;
}

.testimonial-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 28px;
}

.testimonial-card {
    background-color: #2A447A;
    padding: 28px;
    border-radius: 16px;
    transition: transform 0.3s;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.testimonial-card:hover {
    transform: translateY(-6px);
}

.quote-title {
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 14px;
    color: #FFD700;
}

.testimonial-text {
    font-size: 1.05rem;
    opacity: 0.92;
    margin-bottom: 24px;
    color: #E6ECF4;
    flex-grow: 1;
}

.customer-info {
    display: flex;
    align-items: center;
    gap: 14px;
}

.customer-image {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #FFD700;
}

.customer-name {
    font-size: 1.2rem;
    font-weight: 700;
    color: #FFFFFF;
}

.customer-location {
    font-size: 0.95rem;
    opacity: 0.85;
    color: #DDE4EE;
}

/* Enhanced SlideUp Animation with Bounce */
@keyframes slideUp {
    0% { transform: translateY(50px); opacity: 0; }
    70% { transform: translateY(-10px); opacity: 1; }
    85% { transform: translateY(5px); }
    100% { transform: translateY(0); opacity: 1; }
}

/* Responsive Design */
@media (max-width: 768px) {
    .hero h1 {
        font-size: 2.5rem;
    }

    .hero p {
        font-size: 1.2rem;
    }

    .section-title, .st {
        font-size: 2rem;
    }

    .food-grid, .testimonial-grid {
        grid-template-columns: 1fr;
    }

    .hero .btn {
        margin: 12px 0;
        display: block;
    }

    .food-animation {
        width: 100px;
        height: 100px;
        top: 10px;
        right: 10px;
    }

    .card-placeholder {
        height: 200px;
    }

    .food-name {
        font-size: 1.6rem;
    }

    .chef-info, .location-info, .cuisine, .rating-value {
        font-size: 1rem;
    }

    .time, .price {
        font-size: 0.95rem;
    }
}
</style>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <h1>Delightful Homemade Food Delivered with Ease</h1>
        <p>Enjoy authentic home-cooked meals prepared by talented chefs in your neighborhood</p>
        <a href="#top-selling-section" class="btn">Explore Food</a>
        <a href="customer/login.php" class="btn secondary">Customer Login</a>
        <a href="chef/login.php" class="btn secondary">Chef Login</a>
    </div>
    <!-- Food Animation -->
    <div class="food-animation">
        <img src="assets/images/morgi.jfif" alt="মুরগির মাংস">
        <img src="assets/images/aloBorta.jfif" alt="আলু ভর্তা">
        <img src="assets/images/hilsha.jfif" alt="ইলিশ মাছ">
    </div>
</section>

Top Selling Items Section
<section id="top-selling-section" class="section">
    <h2 class="st">Top Selling Items</h2>
    <div class="container">
        <div class="food-grid">
            <?php
            require_once 'includes/db.php';

            // Fetch top-selling items with average ratings
            $query = "SELECT fi.id, fi.name, fi.price, fi.preparation_time, fi.category, 
                             u.name AS chef_name, COALESCE(u.location, 'Not specified') AS chef_location, 
                             SUM(oi.quantity) AS total_sold,
                             COALESCE(AVG(f.rating), 0) AS avg_rating
                      FROM order_items oi
                      JOIN orders o ON oi.order_id = o.id
                      JOIN food_items fi ON oi.food_item_id = fi.id
                      JOIN users u ON fi.chef_id = u.id
                      LEFT JOIN feedback f ON o.id = f.order_id
                      WHERE o.status = 'confirmed'
                      GROUP BY fi.id, fi.name, fi.price, fi.preparation_time, fi.category, 
                               u.name, u.location
                      ORDER BY total_sold DESC
                      LIMIT 6";

            $topSellingItems = $db->select($query);
            if ($topSellingItems === false || empty($topSellingItems)) {
                echo '<p style="text-align: center; grid-column: 1 / -1; color: #5A6A88; font-size: 1.2rem; font-weight: 500;">No top selling items available yet.</p>';
            } else {
                foreach ($topSellingItems as $index => $item) {
                    echo '<div class="card" style="animation-delay: ' . ($index * 0.1) . 's;">';
                    echo '<div class="card-placeholder"></div>';
                    echo '<div class="card-content">';
                    echo '<h2 class="food-name">' . htmlspecialchars($item['name']) . '</h2>';
                    echo '<p class="chef-info">By ' . htmlspecialchars($item['chef_name']) . '</p>';
                    echo '<p class="location-info">Location: ' . htmlspecialchars($item['chef_location']) . '</p>';
                    echo '<div class="cuisine-rating">';
                    echo '<p class="cuisine">' . htmlspecialchars($item['category'] ?: 'Bangla Food') . '</p>';
                    echo '<div class="rating">';
                    echo '<span class="star">★</span>';
                    echo '<span class="rating-value">' . number_format($item['avg_rating'], 1) . '</span>';
                    echo '</div>';
                    echo '</div>';
                    echo '<div class="card-footer">';
                    echo '<div class="time">';
                    echo '<i class="fa-regular fa-clock"></i>';
                    echo '<span>' . htmlspecialchars($item['preparation_time']) . ' Mins</span>';
                    echo '</div>';
                    echo '<div class="price">';
                    echo '<i class="fa-solid fa-tag"></i>';
                    echo '<span>৳' . number_format($item['price'], 2) . '</span>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            }
            ?>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="testimonial-section">
    <div class="container">
        <h2 class="section-title">What Our Customers Say</h2>
        <div class="testimonial-grid">
            <?php
            // Fetch feedback for testimonials
            $feedbackQuery = "SELECT f.id, f.rating, f.comment, f.created_at, 
                                     u.name AS customer_name, u.profile_image, o.delivery_address
                              FROM feedback f
                              JOIN users u ON f.customer_id = u.id
                              JOIN orders o ON f.order_id = o.id
                              ORDER BY f.created_at DESC
                              LIMIT 3";
            $feedbacks = $db->select($feedbackQuery);

            if ($feedbacks === false || empty($feedbacks)) {
                echo '<p style="text-align: center; color: #E6ECF4; font-size: 1.2rem; font-weight: 500;">No feedback available yet.</p>';
            } else {
                foreach ($feedbacks as $index => $feedback) {
                    echo '<div class="testimonial-card" style="animation-delay: ' . ($index * 0.1) . 's;">';
                    echo '<h3 class="quote-title">Rating: ' . $feedback['rating'] . '/5</h3>';
                    echo '<p class="testimonial-text">' . htmlspecialchars($feedback['comment'] ?: 'No comment provided') . '</p>';
                    echo '<div class="customer-info">';
                    echo '<img src="assets/images/' . htmlspecialchars($feedback['profile_image'] ?: 'default.jpg') . '" alt="' . htmlspecialchars($feedback['customer_name']) . '" class="customer-image">';
                    echo '<div class="customer-details">';
                    echo '<h4 class="customer-name">' . htmlspecialchars($feedback['customer_name']) . '</h4>';
                    echo '<p class="customer-location">' . htmlspecialchars($feedback['delivery_address'] ?: 'Not specified') . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            }
            ?>
        </div>
    </div>
</section>

<?php
require_once 'includes/footer.php';
?>